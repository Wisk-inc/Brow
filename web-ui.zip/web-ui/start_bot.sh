#!/bin/bash
export DISCORD_TOKEN="MTMzODU5NDYzNzIyODU0NDAxMQ.GCJgZF.QYfOjiP7aC-PmH1_1tpYQuNmUradmXZl5KQNdE"
export GOOGLE_API_KEY="AIzaSyCnFZz_dzA-qkP97kcHgjAH_EAOXfzVavc"
python discord_bot.py
